package com.example.wsdet.trevalguide;

/**
 * Created by wsdet on 2017/12/9.
 */

interface GetUserCallback {
    public abstract void done(User returnedUser);
}
