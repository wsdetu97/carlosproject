package com.example.wsdet.trevalguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Main2Activity extends AppCompatActivity {
    Spinner spinner2, spinner3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        spinner2 = (Spinner)findViewById(R.id.Spinner2);
        spinner3 = (Spinner)findViewById(R.id.Spinner3);
        Bundle bundle = getIntent().getExtras();
        int optionInt = bundle.getInt("地區",0);
        final int option1Int = bundle.getInt("國家",0);

        spinner2.setSelection(optionInt);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int c = 0;
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] S = {"get","data"};
                if (i == 0) {
                    S = getResources().getStringArray(R.array.option1_array0);
                } else if (i == 1) {
                    S = getResources().getStringArray(R.array.option1_array1);
                } else if (i == 2) {
                    S = getResources().getStringArray(R.array.option1_array2);
                } else if (i == 3) {
                    S = getResources().getStringArray(R.array.option1_array3);
                } else if (i == 4) {
                    S = getResources().getStringArray(R.array.option1_array4);
                }
                ArrayAdapter<String> adt = new ArrayAdapter<String>(Main2Activity.this,android.R.layout.simple_spinner_item, S);
                adt.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                spinner3.setAdapter(adt);
                if (c == 0){
                    spinner3.setSelection(option1Int);
                    c++;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
