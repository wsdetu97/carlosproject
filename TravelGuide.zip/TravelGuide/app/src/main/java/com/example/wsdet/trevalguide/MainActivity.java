package com.example.wsdet.trevalguide;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Spinner spinner, spinner1;
    Button bSearch, bWrite;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner=(Spinner)findViewById(R.id.Spinner);
        spinner1=(Spinner)findViewById(R.id.Spinner1);
        bSearch=(Button)findViewById(R.id.bSearch);
        bWrite=(Button)findViewById(R.id.bWrite);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] S = {"get","data"};
                if (i == 0) {
                    S = getResources().getStringArray(R.array.option1_array0);
                } else if (i == 1) {
                    S = getResources().getStringArray(R.array.option1_array1);
                } else if (i == 2) {
                    S = getResources().getStringArray(R.array.option1_array2);
                } else if (i == 3) {
                    S = getResources().getStringArray(R.array.option1_array3);
                } else if (i == 4) {
                    S = getResources().getStringArray(R.array.option1_array4);
                }
                ArrayAdapter<String> adt = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_item, S);
                adt.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                spinner1.setAdapter(adt);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        bSearch.setOnClickListener(this);
        bWrite.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.bSearch:
                Intent it = new Intent(MainActivity.this, Main2Activity.class);
                Bundle bundle = new Bundle();
                bundle.putInt("地區",spinner.getSelectedItemPosition());
                bundle.putInt("國家",spinner1.getSelectedItemPosition());
                it.putExtras(bundle);
                startActivity(it);
                break;

            case R.id.bWrite:
                startActivity(new Intent(this, LoginActivity.class));
                break;
        }
    }
}