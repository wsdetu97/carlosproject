package com.example.wsdet.trevalguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class UserInterfaceActivity extends AppCompatActivity implements View.OnClickListener {
    TextView tvSend, tvLogout;
    Spinner spinner2, spinner3;
    UserLocalStore userLocalStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_interface);
        tvSend = (TextView)findViewById(R.id.tvSend);
        tvLogout = (TextView)findViewById(R.id.tvLogout);
        spinner2 = (Spinner)findViewById(R.id.Spinner2);
        spinner3 = (Spinner)findViewById(R.id.Spinner3);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] S = {"get","data"};
                if (i == 0) {
                    S = getResources().getStringArray(R.array.option1_array0);
                } else if (i == 1) {
                    S = getResources().getStringArray(R.array.option1_array1);
                } else if (i == 2) {
                    S = getResources().getStringArray(R.array.option1_array2);
                } else if (i == 3) {
                    S = getResources().getStringArray(R.array.option1_array3);
                } else if (i == 4) {
                    S = getResources().getStringArray(R.array.option1_array4);
                }
                ArrayAdapter<String> adt = new ArrayAdapter<String>(UserInterfaceActivity.this,android.R.layout.simple_spinner_item, S);
                adt.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                spinner3.setAdapter(adt);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        tvSend.setOnClickListener(this);
        tvLogout.setOnClickListener(this);

        userLocalStore = new UserLocalStore(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tvSend:
                break;
            case R.id.tvLogout:
                userLocalStore.clearUserData();
                userLocalStore.setUserLoggedIn(false);
                break;
        }
    }
}