package com.example.wsdet.trevalguide;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by wsdet on 2017/12/8.
 */

public class UserLocalStore{

    public static final String SP_NAME = "userDetails";
    SharedPreferences UserLocalDatabase;

    public UserLocalStore(Context context){
        UserLocalDatabase = context.getSharedPreferences(SP_NAME, 0);
    }

    public void storeUserData(User user){
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.putString("name", user.name);
        spEditor.putString("username", user.username);
        spEditor.putString("password", user.password);
        spEditor.commit();
    }

    public User getLoggedInUser(){
        String name = UserLocalDatabase.getString("name", null);
        String username = UserLocalDatabase.getString("username", "");
        String password = UserLocalDatabase.getString("password", "");

        User storedUser = new User(name, username, password);
        return storedUser;
    }

    public void setUserLoggedIn(boolean loggedIn){
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.putBoolean("loggedIn", loggedIn);
        spEditor.commit();
    }

    public void clearUserData(){
        SharedPreferences.Editor spEditor = UserLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }

    public boolean getUserLoggedIn(){
        if (UserLocalDatabase.getBoolean("LoggedIn", false) == true){
            return true;
        } else {
            return false;
        }
    }
}
